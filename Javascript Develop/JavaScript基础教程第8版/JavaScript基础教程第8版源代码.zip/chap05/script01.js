if (top.location != self.location) {
	top.location.replace(self.location);
}
